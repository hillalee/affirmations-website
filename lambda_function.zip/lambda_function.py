def lambda_handler(event, context):
    return {
        "statusCode": 200,
        "body": "Thank you! You are awesome! <3"
    }
